-- Optional controlled seed, SEPARATE from schema migration. Not executed in production.
-- Caller must set: SET ar_rollout.urban_express_org_id = '<verified organization ID>';
-- Approved initial values from the user's 7 October 2026 clarification.
BEGIN;
DO $$
DECLARE org_id INTEGER := current_setting('ar_rollout.urban_express_org_id')::integer;
        organization public.organization_master%ROWTYPE;
BEGIN
    SELECT * INTO STRICT organization FROM public.organization_master WHERE org_id_pk=org_id FOR UPDATE;
    IF organization.org_name NOT ILIKE '%Urban Express%' THEN
        RAISE EXCEPTION 'Selected organization is not Urban Express; verify the seed target';
    END IF;
    IF nullif(btrim(organization.company_registration_number),'') IS NULL THEN
        UPDATE public.organization_master SET company_registration_number='1349832' WHERE org_id_pk=org_id;
    ELSIF btrim(organization.company_registration_number) <> '1349832' THEN
        RAISE EXCEPTION 'Existing company registration conflicts with approved Trade License 1349832; resolve explicitly';
    END IF;
    INSERT INTO public.organization_tax_configuration
        (tax_org_id_fk,tax_code,tax_name,tax_treatment,tax_rate,is_default,is_active,created_by)
    VALUES (org_id,'STANDARD_VAT','Standard VAT','STANDARD',5.00,TRUE,TRUE,'AR approved configuration seed')
    ON CONFLICT (tax_org_id_fk,tax_code) DO NOTHING;
    INSERT INTO public.organization_invoice_configuration
        (invoice_org_id_fk,organization_trn,bank_name,bank_account_name,bank_account_number,iban,signatory_name,signatory_designation,created_by)
    SELECT org_id,'104382694800003','Emirates Islamic Bank','Urban Express Transport L.L.C',
        '3708506470001','AE810340003708506470001','Dr. Mohamad Al Hashimi','Founder & CEO','AR approved configuration seed'
    WHERE NOT EXISTS (SELECT 1 FROM public.organization_invoice_configuration WHERE invoice_org_id_fk=org_id AND is_active);
END $$;
COMMIT;
